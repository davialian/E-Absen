// Sidebar toggle
//index
const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("sidebar");
const closeSidebar = document.getElementById("closeSidebar");

menuBtn.addEventListener("click", () => {
  sidebar.classList.add("open");
});

closeSidebar.addEventListener("click", () => {
  sidebar.classList.remove("open");
});

// Realtime + check in, check out
// Dapatkan tombol dan elemen teks
const checkInBtn = document.getElementById("checkInBtn");
const checkOutBtn = document.getElementById("checkOutBtn");
const statusText = document.getElementById("statusText");

// Fungsi untuk ambil waktu sekarang dalam format jam:menit:detik
function getCurrentTime() {
  const now = new Date();
  return now.toLocaleTimeString(); // contoh output: 10:23:45
}

// Logika Check In
// ------------------------------
// CEK STATUS HARIAN (HANYA SEKALI)
// ------------------------------

// Dapatkan tanggal hari ini (format YYYY-MM-DD)
function getTodayDate() {
  const now = new Date();
  return now.toISOString().split("T")[0];
}

// Ambil status dari localStorage
let savedDate = localStorage.getItem("absen_date");
let hasCheckedIn = localStorage.getItem("has_checked_in") === "true";
let hasCheckedOut = localStorage.getItem("has_checked_out") === "true";

// Reset otomatis kalau hari sudah berganti
const today = getTodayDate();
if (savedDate !== today) {
  localStorage.setItem("absen_date", today);
  localStorage.setItem("has_checked_in", "false");
  localStorage.setItem("has_checked_out", "false");

  hasCheckedIn = false;
  hasCheckedOut = false;
}

// Update tombol ketika halaman dibuka
if (hasCheckedIn) {
  checkInBtn.disabled = true;
  checkInBtn.style.opacity = "0.5";
  statusText.textContent = "Anda sudah Check In hari ini.";
}

if (hasCheckedOut) {
  checkOutBtn.disabled = true;
  checkOutBtn.style.opacity = "0.5";
}

// ------------------------------
// LOGIKA CHECK IN
// ------------------------------
checkInBtn.addEventListener("click", function () {
  if (hasCheckedIn) {
    alert("❌ Kamu sudah Check In hari ini!");
    return;
  }

  const confirmCheckIn = confirm("Apakah kamu yakin ingin Check In sekarang?");
  if (confirmCheckIn) {
    const time = getCurrentTime();
    statusText.textContent = `${time} - Anda telah Check In.`;

    // Simpan ke localStorage
    localStorage.setItem("has_checked_in", "true");
    localStorage.setItem("absen_date", getTodayDate());
    hasCheckedIn = true;

    // Disable tombol
    checkInBtn.disabled = true;
    checkInBtn.style.opacity = "0.5";

    alert(`${time} - Check In berhasil!`);
  }
});

// ------------------------------
// LOGIKA CHECK OUT
// ------------------------------
checkOutBtn.addEventListener("click", function () {
  if (!hasCheckedIn) {
    alert("❌ Kamu belum Check In!");
    return;
  }

  if (hasCheckedOut) {
    alert("❌ Kamu sudah Check Out hari ini!");
    return;
  }

  const confirmCheckOut = confirm("Apakah kamu yakin ingin Check Out sekarang?");
  if (confirmCheckOut) {
    const time = getCurrentTime();
    statusText.textContent = `${time} - Anda telah Check Out.`;

    // Simpan ke localStorage
    localStorage.setItem("has_checked_out", "true");
    hasCheckedOut = true;

    // Disable tombol
    checkOutBtn.disabled = true;
    checkOutBtn.style.opacity = "0.5";

    alert(`${time} - Check Out berhasil!`);
  }
});
//stop index

//start log in
// Login sederhana
const loginBtn = document.getElementById("loginBtn");

loginBtn.addEventListener("click", () => {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (email === "" || password === "") {
    alert("Harap isi semua kolom login!");
  } else if (email === "admin@perusahaan.com" && password === "12345") {
    alert("Login berhasil! Selamat datang 👋");
    window.location.href = "index.html"; // menuju halaman utama
  } else {
    alert("Email atau password salah!");
  }
});
//stop log in

// Strat riwayat_absensi
// --- Riwayat Absen Dummy Data ---
const riwayatTable = document.getElementById("riwayatTable");
if (riwayatTable) {
  const dataRiwayat = [
    { tanggal: "12 JAN 2025", masuk: "08:01", keluar: "17:00", ket: "Hadir" },
    { tanggal: "13 JAN 2025", masuk: "08:05", keluar: "17:02", ket: "Hadir" },
    { tanggal: "14 JAN 2025", masuk: "-", keluar: "-", ket: "Izin" },
  ];

  dataRiwayat.forEach((item) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${item.tanggal}</td>
      <td>${item.masuk}</td>
      <td>${item.keluar}</td>
      <td>${item.ket}</td>
    `;
    riwayatTable.appendChild(row);
  });
}
// Stop riwayat_absensi

// Start pengajuan_cuti
  // ===== Upload file =====
  const fileInput = document.getElementById("inputGroupFile02");
  const fileLabel = document.querySelector(".upload-label");

  if (fileInput && fileLabel) {
    fileInput.addEventListener("change", (e) => {
      const fileName = e.target.files[0]?.name || "Upload";
      fileLabel.textContent = fileName;
    });
  }

  // ===== Submit =====
  const submitBtn = document.getElementById("checkInBtn");
  const form = document.getElementById("cutiForm");

  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("✅ Pengajuan cuti berhasil dikirim!");
      form.reset();
    });
  }

