// Sidebar toggle
//index
const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("sidebar");
const closeSidebar = document.getElementById("closeSidebar");

menuBtn.addEventListener("click", () => {
  sidebar.classList.add("open");
});

closeSidebar.addEventListener("click", () => {
  sidebar.classList.remove("open");
});

// --- MODAL TAMBAH KARYAWAN --- //

// tombol buka modal (ID sesuai HTML kamu)
let openTambahKaryawan = document.getElementById("openTambahKaryawan");

// modal
let modal = document.getElementById("modal");

// tombol X
let closeModalBtn = document.getElementById("closeModalBtn");


// BUKA modal → pakai display: flex (sesuai CSS modal)
openTambahKaryawan.addEventListener("click", function () {
    modal.style.display = "flex";
});


// TUTUP modal → klik tombol X
closeModalBtn.addEventListener("click", function () {
    modal.style.display = "none";
});


// TUTUP modal → klik area hitam di luar box
window.addEventListener("click", function (e) {
    if (e.target === modal) {
        modal.style.display = "none";
    }
});

// Preview foto
document.getElementById("fileInput").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const imgURL = URL.createObjectURL(file);
        document.getElementById("profilePic").src = imgURL;
    }
});




